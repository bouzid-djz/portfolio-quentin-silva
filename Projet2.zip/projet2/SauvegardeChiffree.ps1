Add-Type -AssemblyName System.Windows.Forms

# === PARAMÈTRES ===
$destinationFolder = "D:\Mon Drive"
$sevenZipPath = "C:\Program Files\7-Zip\7z.exe"
$password = "456"

# === Boîte de dialogue de sélection de dossiers ===
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "Choisissez un dossier a sauvegarder"
$dialog.ShowNewFolderButton = $false

$selectedFolders = @()

while ($dialog.ShowDialog() -eq "OK") {
    $selectedFolders += $dialog.SelectedPath
    $reselect = [System.Windows.Forms.MessageBox]::Show("Voulez-vous selectionner un autre dossier ?", "Ajouter un autre dossier", "YesNo")
    if ($reselect -eq "No") { break }
}

if ($selectedFolders.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("Aucun dossier selectionne. Operation annulee.", "Sauvegarde annulee")
    exit
}

# === Création de l'archive pour chaque dossier ===
foreach ($source in $selectedFolders) {
    if (-not (Test-Path $source)) {
        [System.Windows.Forms.MessageBox]::Show("Le dossier source n'existe pas : $source", "Erreur")
        continue
    }

    $folderName = Split-Path $source -Leaf
    $zipName = "$folderName.zip"
    $zipPath = Join-Path $destinationFolder $zipName

    if (Test-Path $zipPath) {
        Remove-Item -Path $zipPath -Force
    }

    if (-not (Test-Path $destinationFolder)) {
        New-Item -ItemType Directory -Path $destinationFolder | Out-Null
    }

    $arguments = "a -tzip `"$zipPath`" `"$source\*`" -r -p$password -mem=AES256"

    $processInfo = New-Object System.Diagnostics.ProcessStartInfo
    $processInfo.FileName = $sevenZipPath
    $processInfo.Arguments = $arguments
    $processInfo.RedirectStandardOutput = $true
    $processInfo.RedirectStandardError = $true
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $processInfo
    $process.Start() | Out-Null
    $process.WaitForExit()

    if ($process.ExitCode -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Le dossier '$folderName' a ete sauvegarde avec succes dans $destinationFolder", "Succes")
    } else {
        [System.Windows.Forms.MessageBox]::Show("Erreur lors de la sauvegarde de '$folderName'", "Erreur")
    }
}
